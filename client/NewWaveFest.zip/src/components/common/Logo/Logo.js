import React from 'react'

import './Logo.scss';

const Logo = ({ links, location }) => (
  <h1 className="logo">Blog.app</h1>
);

export default Logo;
